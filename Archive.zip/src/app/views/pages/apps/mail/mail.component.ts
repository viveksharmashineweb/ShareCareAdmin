// Angular
import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
	selector: 'kt-mail',
	templateUrl: './mail.component.html',
	changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MailComponent { }
